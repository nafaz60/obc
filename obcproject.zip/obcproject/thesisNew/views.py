from datetime import datetime, timezone

from django.core.exceptions import ValidationError
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.utils import timezone
from service import models
from service.models import Appointment, CommandChannel, Rank, Soldier


def loginPage(request):
    return render(request, "login.html")

# thesisNew/views.py
from django.shortcuts import render

#def home(request):
    #return render(request, 'home.html')

def parade_state(request):
    return render(request, 'parade_state.html')

def homePage(request):
    return render(request, "homepage.html")
def paradeStatePage(request):
    # Get the total count of soldiers
    total_soldiers = Soldier.objects.count()
    today = datetime.now().date()
    # Get the count of soldiers with state 'Present'
    present_soldiers = Soldier.objects.filter(state='Present').count()

    # Get the CommandChannel object for A coy
    a_coy = CommandChannel.objects.get(company_name='A coy')
    b_coy = CommandChannel.objects.get(company_name='B coy')
    c_coy = CommandChannel.objects.get(company_name='C coy')
    d_coy = CommandChannel.objects.get(company_name='D coy')
    hq_coy = CommandChannel.objects.get(company_name='HQ coy')

    # Get the count of soldiers with state 'Present' from A coy
    present_soldiers_a_coy = Soldier.objects.filter(state='Present', command_channel=a_coy).count()
    cmh_a_coy = Soldier.objects.filter(state='CMH', command_channel=a_coy).count()
    siq_soldiers_a_coy = Soldier.objects.filter(state='SIQ', command_channel=a_coy).count()
    ppgf_soldiers_a_coy = Soldier.objects.filter(state='PPGF', command_channel=a_coy).count()
    ppg_soldiers_a_coy = Soldier.objects.filter(state='PPG', command_channel=a_coy).count()
    duty_soldiers_a_coy = Soldier.objects.filter(state='DUTY', command_channel=a_coy).count()
    plve_soldiers_a_coy = Soldier.objects.filter(state='P LVE', command_channel=a_coy).count()
    clve_soldiers_a_coy = Soldier.objects.filter(state='C LVE', command_channel=a_coy).count()
    catc_soldiers_a_coy = Soldier.objects.filter(state='CAT C', command_channel=a_coy).count()
    weekend_soldiers_a_coy = Soldier.objects.filter(state='WEEKEND', command_channel=a_coy).count()

    present_soldiers_b_coy = Soldier.objects.filter(state='Present', command_channel=b_coy).count()
    cmh_b_coy = Soldier.objects.filter(state='CMH', command_channel=b_coy).count()
    siq_soldiers_b_coy = Soldier.objects.filter(state='SIQ', command_channel=b_coy).count()
    ppgf_soldiers_b_coy = Soldier.objects.filter(state='PPGF', command_channel=b_coy).count()
    ppg_soldiers_b_coy = Soldier.objects.filter(state='PPG', command_channel=b_coy).count()
    duty_soldiers_b_coy = Soldier.objects.filter(state='DUTY', command_channel=b_coy).count()
    plve_soldiers_b_coy = Soldier.objects.filter(state='P LVE', command_channel=b_coy).count()
    clve_soldiers_b_coy = Soldier.objects.filter(state='C LVE', command_channel=b_coy).count()
    catc_soldiers_b_coy = Soldier.objects.filter(state='CAT C', command_channel=b_coy).count()
    weekend_soldiers_b_coy = Soldier.objects.filter(state='WEEKEND', command_channel=b_coy).count()

    present_soldiers_c_coy = Soldier.objects.filter(state='Present', command_channel=c_coy).count()
    cmh_c_coy = Soldier.objects.filter(state='CMH', command_channel=c_coy).count()
    siq_soldiers_c_coy = Soldier.objects.filter(state='SIQ', command_channel=c_coy).count()
    ppgf_soldiers_c_coy = Soldier.objects.filter(state='PPGF', command_channel=c_coy).count()
    ppg_soldiers_c_coy = Soldier.objects.filter(state='PPG', command_channel=c_coy).count()
    duty_soldiers_c_coy = Soldier.objects.filter(state='DUTY', command_channel=c_coy).count()
    plve_soldiers_c_coy = Soldier.objects.filter(state='P LVE', command_channel=c_coy).count()
    clve_soldiers_c_coy = Soldier.objects.filter(state='C LVE', command_channel=c_coy).count()
    catc_soldiers_c_coy = Soldier.objects.filter(state='CAT C', command_channel=c_coy).count()
    weekend_soldiers_c_coy = Soldier.objects.filter(state='WEEKEND', command_channel=c_coy).count()

    present_soldiers_d_coy = Soldier.objects.filter(state='Present', command_channel=d_coy).count()
    cmh_d_coy = Soldier.objects.filter(state='CMH', command_channel=d_coy).count()
    siq_soldiers_d_coy = Soldier.objects.filter(state='SIQ', command_channel=d_coy).count()
    ppgf_soldiers_d_coy = Soldier.objects.filter(state='PPGF', command_channel=d_coy).count()
    ppg_soldiers_d_coy = Soldier.objects.filter(state='PPG', command_channel=d_coy).count()
    duty_soldiers_d_coy = Soldier.objects.filter(state='DUTY', command_channel=d_coy).count()
    plve_soldiers_d_coy = Soldier.objects.filter(state='P LVE', command_channel=d_coy).count()
    clve_soldiers_d_coy = Soldier.objects.filter(state='C LVE', command_channel=d_coy).count()
    catc_soldiers_d_coy = Soldier.objects.filter(state='CAT C', command_channel=d_coy).count()
    weekend_soldiers_d_coy = Soldier.objects.filter(state='WEEKEND', command_channel=d_coy).count()

    present_soldiers_hq_coy = Soldier.objects.filter(state='Present', command_channel=hq_coy).count()
    cmh_hq_coy = Soldier.objects.filter(state='CMH', command_channel=hq_coy).count()
    siq_soldiers_hq_coy = Soldier.objects.filter(state='SIQ', command_channel=hq_coy).count()
    ppgf_soldiers_hq_coy = Soldier.objects.filter(state='PPGF', command_channel=hq_coy).count()
    ppg_soldiers_hq_coy = Soldier.objects.filter(state='PPG', command_channel=hq_coy).count()
    duty_soldiers_hq_coy = Soldier.objects.filter(state='DUTY', command_channel=hq_coy).count()
    plve_soldiers_hq_coy = Soldier.objects.filter(state='P LVE', command_channel=hq_coy).count()
    clve_soldiers_hq_coy = Soldier.objects.filter(state='C LVE', command_channel=hq_coy).count()
    catc_soldiers_hq_coy = Soldier.objects.filter(state='CAT C', command_channel=hq_coy).count()
    weekend_soldiers_hq_coy = Soldier.objects.filter(state='WEEKEND', command_channel=hq_coy).count()
    total_cmh = cmh_a_coy + cmh_b_coy + cmh_c_coy + cmh_d_coy + cmh_hq_coy
    total_siq = siq_soldiers_a_coy + siq_soldiers_b_coy + siq_soldiers_c_coy + siq_soldiers_d_coy + siq_soldiers_hq_coy
    total_ppgf = ppgf_soldiers_a_coy + ppgf_soldiers_b_coy + ppgf_soldiers_c_coy + ppgf_soldiers_d_coy + ppgf_soldiers_hq_coy
    total_ppg = ppg_soldiers_a_coy + ppg_soldiers_b_coy + ppg_soldiers_c_coy + ppg_soldiers_d_coy + ppg_soldiers_hq_coy
    total_duty = duty_soldiers_a_coy + duty_soldiers_b_coy + duty_soldiers_c_coy + duty_soldiers_d_coy + duty_soldiers_hq_coy
    total_plve = plve_soldiers_a_coy + plve_soldiers_b_coy + plve_soldiers_c_coy + plve_soldiers_d_coy + plve_soldiers_hq_coy
    total_clve = clve_soldiers_a_coy + clve_soldiers_b_coy + clve_soldiers_c_coy + clve_soldiers_d_coy + clve_soldiers_hq_coy
    total_catc = catc_soldiers_a_coy + catc_soldiers_b_coy + catc_soldiers_c_coy + catc_soldiers_d_coy + catc_soldiers_hq_coy
    total_weekend = weekend_soldiers_a_coy + weekend_soldiers_b_coy + weekend_soldiers_c_coy + weekend_soldiers_d_coy + weekend_soldiers_hq_coy
    #total_offparade = total_cmh + total_siq + total_ppgf + total_ppg + total_duty + total_plve + total_clve + total_catc + total_weekend
    total_present = present_soldiers_a_coy + present_soldiers_b_coy + present_soldiers_c_coy + present_soldiers_d_coy + present_soldiers_hq_coy
    #total_absent = absent_soldiers_a_coy + absent_soldiers_b_coy + absent_soldiers_c_coy + absent_soldiers_d_coy + absent_soldiers_hq_coy

    # Calculate the count of absent soldiers
    absent_soldiers = total_soldiers - present_soldiers

    # Get the names of soldiers whose state is not "Present"
    non_present_soldiers = Soldier.objects.exclude(state='Present').values_list('name', 'state')

    context = {
        'today': today,
        'total_present': total_present,
        'total_cmh': total_cmh,
        'total_siq': total_siq,
        'total_ppgf': total_ppgf,
        'total_ppg': total_ppg,
        'total_duty': total_duty,
        'total_plve': total_plve,
        'total_clve': total_clve,
        'total_catc': total_catc,
        'total_weekend': total_weekend,
        'total_soldiers': total_soldiers,
        'present_soldiers': present_soldiers,
        'absent_soldiers': absent_soldiers,
        'non_present_soldiers': non_present_soldiers,
        'present_soldiers_a_coy': present_soldiers_a_coy,
        'present_soldiers_b_coy': present_soldiers_b_coy,
        'present_soldiers_c_coy': present_soldiers_c_coy,
        'total_plve': total_plve,
        'total_duty': total_duty,
        'total_soldiers': total_soldiers,
        'total_cmh': total_cmh,
        'present_soldiers': present_soldiers,
        'absent_soldiers': absent_soldiers,
        'present_soldiers_a_coy': present_soldiers_a_coy,
        'cmh_a_coy': cmh_a_coy,
        'siq_soldiers_a_coy': siq_soldiers_a_coy,
        'ppgf_soldiers_a_coy': ppgf_soldiers_a_coy,
        'ppg_soldiers_a_coy': ppg_soldiers_a_coy,
        'duty_soldiers_a_coy': duty_soldiers_a_coy,
        'plve_soldiers_a_coy': plve_soldiers_a_coy,
        'clve_soldiers_a_coy': clve_soldiers_a_coy,
        'catc_soldiers_a_coy': catc_soldiers_a_coy,
        'weekend_soldiers_a_coy': weekend_soldiers_a_coy,
        'present_soldiers_b_coy': present_soldiers_b_coy,
        'cmh_b_coy': cmh_b_coy,
        'siq_soldiers_b_coy': siq_soldiers_b_coy,
        'ppgf_soldiers_b_coy': ppgf_soldiers_b_coy,
        'ppg_soldiers_b_coy': ppg_soldiers_b_coy,
        'duty_soldiers_b_coy': duty_soldiers_b_coy,
        'plve_soldiers_b_coy': plve_soldiers_b_coy,
        'clve_soldiers_b_coy': clve_soldiers_b_coy,
        'catc_soldiers_b_coy': catc_soldiers_b_coy,
        'weekend_soldiers_b_coy': weekend_soldiers_b_coy,
        'present_soldiers_c_coy': present_soldiers_c_coy,
        'cmh_c_coy': cmh_c_coy,
        'siq_soldiers_c_coy': siq_soldiers_c_coy,
        'ppgf_soldiers_c_coy': ppgf_soldiers_c_coy,
        'ppg_soldiers_c_coy': ppg_soldiers_c_coy,
        'duty_soldiers_c_coy': duty_soldiers_c_coy,
        'plve_soldiers_c_coy': plve_soldiers_c_coy,
        'clve_soldiers_c_coy': clve_soldiers_c_coy,
        'catc_soldiers_c_coy': catc_soldiers_c_coy,
        'weekend_soldiers_c_coy': weekend_soldiers_c_coy,
        'present_soldiers_d_coy': present_soldiers_d_coy,
        'cmh_d_coy': cmh_d_coy,
        'siq_soldiers_d_coy': siq_soldiers_d_coy,
        'ppgf_soldiers_d_coy': ppgf_soldiers_d_coy,
        'ppg_soldiers_d_coy': ppg_soldiers_d_coy,
        'duty_soldiers_d_coy': duty_soldiers_d_coy,
        'plve_soldiers_d_coy': plve_soldiers_d_coy,
        'clve_soldiers_d_coy': clve_soldiers_d_coy,
        'catc_soldiers_d_coy': catc_soldiers_d_coy,
        'weekend_soldiers_d_coy': weekend_soldiers_d_coy,
        'present_soldiers_hq_coy': present_soldiers_hq_coy,
        'cmh_hq_coy': cmh_hq_coy,
        'siq_soldiers_hq_coy': siq_soldiers_hq_coy,
        'ppgf_soldiers_hq_coy': ppgf_soldiers_hq_coy,
        'ppg_soldiers_hq_coy': ppg_soldiers_hq_coy,
        'duty_soldiers_hq_coy': duty_soldiers_hq_coy,
        'plve_soldiers_hq_coy': plve_soldiers_hq_coy,
        'clve_soldiers_hq_coy': clve_soldiers_hq_coy,
        'catc_soldiers_hq_coy': catc_soldiers_hq_coy,
        'weekend_soldiers_hq_coy': weekend_soldiers_hq_coy,
        'non_present_soldiers': non_present_soldiers,  # Pass the names of non-present soldiers
    }

    return render(request, "paradeState.html", context)

def adminPage(request):
    return render(request, "admin.html")
def dutiesPage(request):
    return render(request, "duties.html")
def dataPage(request):
    ranks = Rank.objects.all()
    appointments = Appointment.objects.all()
    command_channels = CommandChannel.objects.all()

    context = {
        'ranks': ranks,
        'appointments': appointments,
        'command_channels': command_channels,
    }

    return render(request, "dataentry.html", context)
def ComchPage(request):
    return render(request, "comch.html")
def RankPage(request):
    return render(request, "rank.html")
def ApptsPage(request):
    return render(request, "appts.html")

def save_appointment(request):
    if request.method == 'POST':
        appointment_name = request.POST.get('appointment_name')

        # Create and save the Appointment object
        appointment = Appointment.objects.create(appointment_name=appointment_name)

        # Return a simple success message
        return HttpResponse('Appointment saved successfully.')

    return render(request, 'appts.html')

def saveCommandChannel(request):
    if request.method == 'POST':
        company_name = request.POST['company_name']
        company_commander = request.POST['company_commander']
        sjco = request.POST['sjco']
        csm = request.POST['csm']

        command_channel = CommandChannel.objects.create(
            company_name=company_name,
            company_commander=company_commander,
            sjco=sjco,
            csm=csm
        )

        # Save the CommandChannel instance
        command_channel.save()

    return render(request, 'comch.html')

def save_Rank(request):
    if request.method == 'POST':
        rank_value = request.POST.get('rank')

        # Check if the rank_value is not empty
        if not rank_value:
            error_message = 'Rank value is required.'
            return render(request, 'rank.html', {'error_message': error_message})

        # Assuming 'Rank' is a model, create and save the Rank object
        rank = Rank(rank=rank_value)
        rank.save()

        # Redirect to the same page or another appropriate page
        return redirect(request.META.get('HTTP_REFERER', 'rank.html'))
    else:
        # Handle GET requests (optional)
        return HttpResponseBadRequest("Invalid request method")

def saveSoldier(request):
    if request.method == "POST":
        # Extract form data
        name = request.POST.get('name')
        personel_no = request.POST.get('personel_no')
        trade = request.POST.get('trade')
        rank_id = request.POST.get('rank')
        rank = Rank.objects.get(id=rank_id) if rank_id else None
        appointments_id = request.POST.get('appointments')
        appointment = Appointment.objects.get(id=appointments_id) if appointments_id else None
        command_channel_id = request.POST.get('command_channel')
        command_channel = CommandChannel.objects.get(id=command_channel_id) if command_channel_id else None
        image = request.FILES.get('image')
       # Get the uploaded image file

        # Create soldier object
        if image:
            soldier = Soldier(
                name=name,
                personel_no=personel_no,
                trade=trade,
                rank=rank,
                appointments=appointment,
                command_channel=command_channel,
                image=image
            )
            soldier.save()

    message = "Added successfully"
    return HttpResponse(message)


def soldiers_from_a_coy(request):
    # Query the CommandChannel model to get the 'A coy' object
    a_coy = CommandChannel.objects.get(company_name='A coy')

    # Use the related_name or related_query_name you defined in your Soldier model
    soldiers_a_coy = Soldier.objects.filter(command_channel=a_coy)

    return render(request, 'acoy.html', {'soldiers': soldiers_a_coy})
def soldiers_from_b_coy(request):
    # Query the CommandChannel model to get the 'A coy' object
    b_coy = CommandChannel.objects.get(company_name='B coy')

    # Use the related_name or related_query_name you defined in your Soldier model
    soldiers_b_coy = Soldier.objects.filter(command_channel=b_coy)

    return render(request, 'bcoy.html', {'soldiers': soldiers_b_coy})
def soldiers_from_c_coy(request):
    # Query the CommandChannel model to get the 'A coy' object
    c_coy = CommandChannel.objects.get(company_name='C coy')

    # Use the related_name or related_query_name you defined in your Soldier model
    soldiers_c_coy = Soldier.objects.filter(command_channel=c_coy)

    return render(request, 'ccoy.html', {'soldiers': soldiers_c_coy})
def soldiers_from_d_coy(request):
    # Query the CommandChannel model to get the 'A coy' object
    d_coy = CommandChannel.objects.get(company_name='D coy')

    # Use the related_name or related_query_name you defined in your Soldier model
    soldiers_d_coy = Soldier.objects.filter(command_channel=d_coy)

    return render(request, 'dcoy.html', {'soldiers': soldiers_d_coy})
def soldiers_from_hq_coy(request):
    # Query the CommandChannel model to get the 'A coy' object
    hq_coy = CommandChannel.objects.get(company_name='HQ coy')

    # Use the related_name or related_query_name you defined in your Soldier model
    soldiers_hq_coy = Soldier.objects.filter(command_channel=hq_coy)

    return render(request, 'hqcoy.html', {'soldiers': soldiers_hq_coy})



def service_details(request, service_id):
    soldier = Soldier.objects.get(id=service_id)
    return render(request, 'details.html', {'soldier': soldier})

def update_soldier_state(request, soldier_id):
    if request.method == 'POST':
        selected_option = request.POST.get('state')

        # Update the soldier's state
        soldier = get_object_or_404(Soldier, id=soldier_id)
        soldier.state = selected_option
        soldier.save()

        # Redirect to the soldier details page or another appropriate page
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        # Handle GET requests (optional)
        return HttpResponseBadRequest("Invalid request method")


