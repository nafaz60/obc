"""
URL configuration for thesisNew project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.template.context_processors import static
from django.urls import path
from thesisNew import views, settings
from thesisNew.views import update_soldier_state
from . import views








urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.loginPage),
    path('home/', views.homePage),
    path('home/home', views.homePage),
    path('home/parade-state', views.paradeStatePage),
    path('parade-state', views.paradeStatePage),
    path('admin-page', views.adminPage),
    #path('duties', views.dutiesPage),
    path('update_soldier_state', update_soldier_state),
    path('home/data-entry', views.dataPage),
    path('data-entry', views.dataPage),
    path('comch', views.ComchPage),
    path('home/rank', views.RankPage),
    #path('cmh_name', views.paradeStatepage),
    path('rank', views.RankPage),
    path('home/appts', views.ApptsPage),
    path('appts', views.ApptsPage),
    path('save_appointment/', views.save_appointment, name='save_appointment'),
    path('saveCommandChannel/', views.saveCommandChannel, name='saveCommandChannel'),
    #path('saveCourse/', views.saveCourse, name='saveCourse'),
    #path('saveIPFT/', views.saveIPFT, name='saveIPFT'),
    #path('save_MedicalDisposal/', views.saveMedicalDisposal, name='save_MedicalDisposal'),
    #path('saveRET/', views.saveRET, name='saveRET'),
    #path('saveCompetition/', views.saveCompetition, name='saveCompetition'),
    #path('saveFiringStandard/', views.saveFiringStandard, name='saveFiringStandard'),
    #path('savePunishment/', views.savePunishment, name='savePunishment'),
    #path('saveEvent/', views.saveEvent, name='saveEvent'),
    #path('save_Cycle/', views.save_Cycle, name='save_Cycle'),
    path('save_rank/', views.save_Rank, name='save_rank'),
    #path('home/saveSoldier', views.saveSoldier, name='saveSoldier'),
    path('save_soldier/', views.saveSoldier, name='save_soldier'),
    path('home/a-coy', views.soldiers_from_a_coy, name='soldiers_from_a_coy'),
    path('home/b-coy', views.soldiers_from_b_coy, name='soldiers_from_b_coy'),
    path('home/c-coy', views.soldiers_from_c_coy, name='soldiers_from_c_coy'),
    path('home/d-coy', views.soldiers_from_d_coy, name='soldiers_from_d_coy'),
    path('home/hq-coy', views.soldiers_from_hq_coy, name='soldiers_from_hq_coy'),
    path('details/<int:service_id>/', views.service_details, name='service_details'),
    path('update_state/<int:soldier_id>/', update_soldier_state, name='update_state'),
    #path('leave', views.LeavePage),
    #path('generate-pdf/', views.generate_pdf, name='generate_pdf'),
]



if settings.DEBUG:
    urlpatterns += [
        path('details/<int:service_id>/', views.service_details, name='service_details'),
    ]

    # Add the static URL pattern for serving media files
    from django.conf.urls.static import static
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

