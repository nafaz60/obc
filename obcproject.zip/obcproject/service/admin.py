from django.contrib import admin

from service.models import (
    Rank,
    Appointment,
    CommandChannel,
    Soldier,
)

admin.site.register(Rank)
admin.site.register(Appointment)
admin.site.register(CommandChannel)
admin.site.register(Soldier)


# Register your models here.
