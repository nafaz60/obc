from datetime import timezone
from django.db.models import Q
from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.utils import timezone as tz
from django.db import models

class Rank(models.Model):
    rank = models.CharField(max_length=100)

    def __str__(self):
        return self.rank


class Appointment(models.Model):
    appointment_name = models.CharField(max_length=100)
    def __str__(self):
        return self.appointment_name
class CommandChannel(models.Model):
    company_name = models.CharField(max_length=100)
    company_commander = models.CharField(max_length=100)
    sjco = models.CharField(max_length=100)
    csm = models.CharField(max_length=100)

    def __str__(self):
        return self.company_name
    
class Soldier(models.Model):

    name = models.CharField(max_length=100)
    personel_no = models.CharField(max_length=20, unique=True)
    trade = models.CharField(max_length=50)
    #address = models.TextField()
    #blood_group = models.CharField(max_length=5)
    rank = models.ForeignKey(Rank, on_delete=models.CASCADE)
    #age = models.PositiveIntegerField()
    #date_of_birth = models.DateField()
    #service_age = models.PositiveIntegerField()
    #date_of_joining = models.DateField()
    #mobile_number = models.CharField(max_length=20)
    #medical_category = models.CharField(max_length=50)
    #promotion_date = models.DateField()
    #height = models.FloatField()
    #weight = models.FloatField()
    #last_served_unit = models.CharField(max_length=100)
    #last_served_appointment = models.CharField(max_length=100)
    #last_opr_marks = models.PositiveIntegerField()
    #living_status = models.BooleanField(default=True)
    #sex = models.CharField(max_length=10)
    appointments = models.OneToOneField(Appointment, on_delete=models.SET_NULL, null=True)
    image = models.ImageField(upload_to="static/images", null=True, blank=True)
    command_channel = models.ForeignKey(CommandChannel, on_delete=models.CASCADE, null=True, blank=True)
    state = models.CharField(max_length=20, default='Present')
    # Timestamps for each state
    # Timestamps for each state
    #last_leave_occurrence = models.DateTimeField(null=True, blank=True, auto_now=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._original_state = self.state

