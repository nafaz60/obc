# forms.py
from django import forms
from .models import ServiceSoldier

class ServiceSoldierForm(forms.ModelForm):
    class Meta:
        model = ServiceSoldier
        fields = [
            'name', 'personel_no', 'trade', 'marital_status', 'address', 'blood_group',
            'age', 'date_of_birth', 'service_age', 'date_of_joining', 'mobile_number',
            'medical_category', 'promotion_date', 'height', 'weight', 'last_served_unit',
            'last_served_appointment', 'last_opr_marks', 'living_status', 'sex', 'image',
            'appointments', 'command_channel', 'rank', 'state', 'last_leave_occurrence'
        ]
